Output results will be saved in timestamped folders.
