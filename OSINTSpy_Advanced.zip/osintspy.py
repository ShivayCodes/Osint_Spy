import argparse, os
from core import auto_type, output_writer, utils
from modules import email_lookup, username_search, domain_info, phone_lookup, ip_lookup
from modules import social_media_enum, subdomain_enum, whois_lookup

def run_search(target, ttype, verbose):
    all_data = {}
    try:
        if ttype == "email":
            all_data.update(email_lookup.search(target, verbose))
        elif ttype == "username":
            all_data.update(username_search.search(target, verbose))
            all_data.update(social_media_enum.search(target, verbose))
        elif ttype == "domain":
            all_data.update(domain_info.search(target, verbose))
            all_data.update(subdomain_enum.search(target, verbose))
            all_data.update(whois_lookup.search(target, verbose))
        elif ttype == "phone":
            all_data.update(phone_lookup.search(target, verbose))
        elif ttype == "ip":
            all_data.update(ip_lookup.search(target, verbose))
    except Exception as e:
        all_data["Error"] = str(e)
    return all_data

def process_target(target, ttype, verbose, json_out):
    if ttype == "auto":
        ttype = auto_type.detect_type(target)
        utils.verbose_print(verbose, f"Auto-detected type: {ttype}")
    results = run_search(target, ttype, verbose)
    output_writer.write_output(results, target, output_json=json_out)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", required=True, help="Target value or file")
    parser.add_argument("--type", default="auto", help="Type of target (email, username, phone, ip, domain)")
    parser.add_argument("--verbose", action="store_true", help="Verbose output")
    parser.add_argument("--json", action="store_true", help="Also output JSON")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    args = parser.parse_args()

    try:
        if os.path.isfile(args.target):
            with open(args.target, "r") as f:
                targets = f.read().splitlines()
        else:
            targets = [args.target]

        for t in targets:
            process_target(t.strip(), args.type, args.verbose, args.json)
    except Exception as e:
        if args.debug:
            raise
        else:
            print(f"[!] Error: {str(e)}")

if __name__ == "__main__":
    main()
