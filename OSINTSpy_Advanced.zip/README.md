# OSINTSpy Advanced

Advanced Python-based OSINT tool with multi-input support, smart target detection, verbose/debug mode, JSON/XML output, and more.

## Features
- Email, phone, domain, username, IP, subdomains, WHOIS, DNS, social media enum
- JSON and XML output in timestamped folders
- Smart type detection with `--auto`
- Verbose and debug support

## Usage

```bash
python osintspy.py --target input.txt --json --auto --verbose
```

## License
MIT
