import requests

def search(domain, verbose=False):
    if verbose:
        print(f"[SUBDOMAIN] Enumerating subdomains for {domain}")
    return {
        "subdomains": f"sub.{domain}, mail.{domain}"
    }
