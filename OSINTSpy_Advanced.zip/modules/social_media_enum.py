def search(target, verbose=False):
    if verbose:
        print(f"[SOCIAL] Checking social media for {target}")
    return {
        "GitHub": f"https://github.com/{target}",
        "Twitter": f"https://twitter.com/{target}"
    }
