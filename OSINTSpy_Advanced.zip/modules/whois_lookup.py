import whois

def search(domain, verbose=False):
    if verbose:
        print(f"[WHOIS] Performing WHOIS lookup for {domain}")
    try:
        data = whois.whois(domain)
        return {"Registrar": str(data.registrar), "Creation_Date": str(data.creation_date)}
    except Exception as e:
        return {"Error": str(e)}
