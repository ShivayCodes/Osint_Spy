def verbose_print(enabled, msg):
    if enabled:
        print(f"[+] {msg}")
