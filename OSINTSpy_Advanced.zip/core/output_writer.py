import os, json, xml.etree.ElementTree as ET
from datetime import datetime

def write_output(data, target, output_json=False):
    ts = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    folder = f"output/{ts}"
    os.makedirs(folder, exist_ok=True)

    xml_root = ET.Element("OSINT_Report")
    ET.SubElement(xml_root, "Target").text = target
    for key, value in data.items():
        item = ET.SubElement(xml_root, "Item")
        ET.SubElement(item, "Key").text = key
        ET.SubElement(item, "Value").text = str(value)

    tree = ET.ElementTree(xml_root)
    tree.write(f"{folder}/report.xml", encoding="utf-8", xml_declaration=True)

    if output_json:
        with open(f"{folder}/report.json", "w") as f:
            json.dump(data, f, indent=4)
