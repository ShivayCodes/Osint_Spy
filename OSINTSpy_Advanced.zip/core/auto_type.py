import re

def detect_type(target):
    if re.match(r"^\d+\.\d+\.\d+\.\d+$", target):
        return "ip"
    elif "@" in target:
        return "email"
    elif re.match(r"^\+?\d{7,15}$", target):
        return "phone"
    elif "." in target:
        return "domain"
    else:
        return "username"
